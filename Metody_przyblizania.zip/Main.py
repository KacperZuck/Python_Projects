import timeit
from math import sin
import pandas as pd # do danych
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from matplotlib import ticker\

N = 1260
tolerance = 1e-9
max_loops = 1000

def DECLARE(N):
    A = [[0.0 for j in range(N)] for i in range(N)]
    b = [0.0 for k in range(N)]
    return A, b
def DECLARE_X(N):
    return np.zeros(N)
def INSERT_A(a1,a2,a3,A):
    for i in range(N):
        A[i][i] = a1
        if i > 0:
            A[i][i - 1] = a2
        if i < N - 1:
            A[i][i + 1] = a2
        if i > 1:
            A[i][i - 2] = a3
        if i < N - 2:
            A[i][i + 2] = a3
    return A

def INSERT_B(b):
    for i in range(N):
        b[i] = float(sin(i*5))
    return b

#TODO -- JACOBI
def JACOBI(A,x):
    A = np.array(A)
    b_vec = np.array(b) #TODO ZAMIANA NA b i sprawdzic czy sdziała // i  x_new
    D = np.diag(A)
    R = A - np.diagflat(D)
    residuum = []
    residuum.append(np.linalg.norm(np.dot(A, x) - b_vec))
    count = 0

    time = timeit.default_timer()
    while count <= max_loops:
        x_new = (b_vec - np.dot(R, x)) / D
        residuum.append(np.linalg.norm(np.dot(A, x_new) - b_vec))
        count += 1
        if residuum[-1] < tolerance:
            break
        elif residuum[-1] >= float('inf'):
            print("Inf")
            break
        x = x_new
    end = timeit.default_timer() - time
    if count == max_loops:
        print("Maksymalna ilosc iteracji w Jacobi")
    return x, count, residuum, end

#TODO -- GAUSS
def GAUSS(A,x):
    residuum = []
    count = 0
    U = np.triu(A, 1)
    T = A - U

    time = timeit.default_timer()
    residuum.append( np.linalg.norm(np.matmul(A, x) - b))

    while count <= max_loops:
        x = np.linalg.solve(T, b - np.matmul(U, x))
        residuum.append(np.linalg.norm(np.matmul(A, x) - b))
        count += 1
        if residuum[-1] < tolerance:
            break
        if residuum[-1] == float('inf'):
            print("Inf")
            break
    end = timeit.default_timer() - time
    if count == max_loops:
        print("Maksymalna ilość iteracji w Gauss-Seidel")
    return x, count, residuum, end

def lu_decomposition(A):
    n = A.shape[0]
    L = np.zeros_like(A)
    U = np.zeros_like(A)

    for i in range(n):
        L[i, i] = 1.0
        for j in range(i, n):
            U[i, j] = A[i, j] - np.dot(L[i, :i], U[:i, j])
        for j in range(i + 1, n):
            if U[i, i] == 0:
                raise ZeroDivisionError("Zerowy element na przekątnej – brak pivotowania")
            L[j, i] = (A[j, i] - np.dot(L[j, :i], U[:i, i])) / U[i, i]
    return L, U

def DIRECT(A):
    A = np.array(A, dtype=float)
    b_vec = np.array(b, dtype=float)

    start = timeit.default_timer()

    L, U = lu_decomposition(A)
    y = np.linalg.solve(L, b_vec)
    x = np.linalg.solve(U, y)

    residuum = np.linalg.norm(np.dot(A, x) - b_vec)
    end = timeit.default_timer() - start

    return x, residuum, end

def PLOT(count, residoum, string, log = 1):
    buff = []
    for i in range(count):
        buff.append({"Residoum": residoum[i], "Powtorzenia": i})
    pd.set_option('display.float_format', '{:.2e-10}'.format)
    df_data = pd.DataFrame(buff)
    plt.figure(figsize=(15, 10))
    sns.lineplot( data=df_data , y="Residoum", x="Powtorzenia", color="g", label=f"{string}")
    if 1 == log: # dodanie dla logarytmicznego wykresu
        plt.yscale('log')
    plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.1e-10'))
    plt.xlabel("Liczba iteracji")
    plt.ylabel("Norma Residoum")
    plt.title(f"Metoda {string}")
    #plt.xticks(ticks=range(0, len(df_data), 5), rotation=45)
    plt.grid(True)
    plt.show()
def PLOT_2(data, string,log = 1):
#    pd.set_option('display.float_format', '{:.2e-10}'.format)
    df_data = pd.DataFrame(data)
    plt.figure(figsize=(25, 20))
    sns.lineplot(data=df_data, y="Jacobi", x="Liczba niewiadomych", label="Jacobi", color="g")
    sns.lineplot(data=df_data, y="Gauss", x="Liczba niewiadomych", label="Gauss", color="orange")
    sns.lineplot(data=df_data, y="Bezposrednia LU", x="Liczba niewiadomych", label="LU", color="b")
    plt.xlabel("Rozmiar danych")
    plt.ylabel("Czas")
    plt.title(f"{string}")
    if 1 == log: # dodanie dla logarytmicznego wykresu
        plt.yscale('log')
 #   plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.1e-10'))
    #plt.xticks(ticks=range(0, len(df_data), 5), rotation=45)
    plt.grid(True)
    plt.show()

#TODO -- A
A,b = DECLARE(N)
x_j = DECLARE_X(N)
x_g = DECLARE_X(N)
a1,a2,a3 = 11.0,-1.0,-1.0

A = INSERT_A(a1,a2,a3,A)
b = INSERT_B(b)
print("A done")

# #TODO-- B
x_j,count_j, residoum_j, time_j = JACOBI(A,x_j)
PLOT(count_j, residoum_j, "Jacobi")

x_g,count_g, residoum_g, time_g = GAUSS(A,x_g)
PLOT(count_g, residoum_g, "GAUSS")
print("B done")
#TODO -- C
a1,a2,a3 = 3.0,-1.0,-1.0
A = INSERT_A(a1,a2,a3,A)
x_j = DECLARE_X(N)
x_g = DECLARE_X(N)
x_j,count_j, residoum_j, time_j = JACOBI(A,x_j)
PLOT(count_j, residoum_j, "JACOBI")
x_g,count_g, residoum_g, time_g = GAUSS(A,x_g)
PLOT(count_g, residoum_g, "GAUSS")
print("C done")
#TODO -- D
    # direct
x, resudoum_d, time_d = DIRECT(A)
print("Norma residoum: ", resudoum_d) # np.linalg.norm(resudoum_d)

#TODO -- E
reSize = [100,500,1000,1500,2000,2500,3000,3500,4000]
data = []
for i in range(len(reSize)):
    N = reSize[i]
    print(N)
    A,b = DECLARE(N)
    x_j = DECLARE_X(N)  # ???
    x_g = DECLARE_X(N)
    x_d = DECLARE_X(N)
    a1,a2,a3 = 11.0,-1.0,-1.0   # z zadania A

    A = INSERT_A(a1,a2,a3,A)
    b = INSERT_B(b)

        # 3 metody
    x_j,count_j, residoum_j, time_j = JACOBI(A,x_j)
    x_g,count_g, residoum_g, time_g = GAUSS(A,x_g)
    x_d,resudoum_d, time_d = DIRECT(A)
    # dane do wykresow dla każdej
    data.append({"Liczba niewiadomych": N, "Jacobi": time_j, "GAUSS": time_g, "LU": time_d })

print("E done")
PLOT_2(data, "Porownanie trzech metod logarytmicznie")
PLOT_2(data,"Porownanie trzech metod liniowo", 0)
